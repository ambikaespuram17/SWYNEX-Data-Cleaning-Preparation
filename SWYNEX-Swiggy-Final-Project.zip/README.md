# Swiggy Restaurant Data Analytics — SWYNEX Final Project

## 1. Project Overview
This project analyzes a cleaned Swiggy restaurant dataset to understand restaurant pricing,
ratings, cuisine patterns, geographic concentration, vegetarian availability, and promotional offers.
The workflow covers data cleaning, exploratory data analysis (EDA), and an interactive BI dashboard.

**Tools:** Python, Pandas, NumPy, Matplotlib, Power BI, GitHub

## 2. Problem Statement
Food-delivery platforms contain large volumes of restaurant-level information, but raw listings can
contain missing values, inconsistent fields, duplicates, and mixed categorical values. The objective is
to transform the restaurant dataset into an analysis-ready format and identify patterns that can support
restaurant segmentation, pricing decisions, promotional planning, and location-level business analysis.

## 3. Dataset Information
- **Rows:** 139,321
- **Columns:** 13
- **Locations:** 581
- **Main fields:** restaurant_name, cuisine, rating, number_of_ratings, average_price,
  number_of_offers, offer_name, area, pure_veg, location, price_category, rating_category,
  popularity_category.
- **Important limitation:** `number_of_ratings` is missing for all rows in the supplied cleaned file,
  and `popularity_category` is therefore also unavailable. These fields should not be interpreted as
  measured values in the final analysis.

## 4. Data Cleaning Process
1. Loaded the restaurant dataset into Pandas.
2. Reviewed column names, data types, shape, missing values, and duplicate records.
3. Checked categorical consistency for vegetarian status, location, price category, and rating category.
4. Preserved meaningful missing values rather than inventing customer-rating counts.
5. Used derived categories already present in the cleaned dataset for price and rating segmentation.
6. Checked for extreme prices using distribution/IQR-based analysis.
7. Saved the cleaned dataset for EDA and dashboard development.

### Data quality snapshot
- Duplicate rows: **0**
- Missing rating values: **33,457**
- Missing cuisine values: **27**
- Missing offer names: **1,752**
- Missing number of ratings: **139,321**
- Missing popularity category: **139,321**

## 5. Analysis Performed
The EDA examined:
- Descriptive statistics and dataset structure
- Missing-value and duplicate checks
- Rating distribution
- Price distribution and price categories
- Location concentration
- Cuisine frequency
- Vegetarian vs non-vegetarian mix
- Promotional offer counts
- Price outlier detection
- Relationships among available numerical variables

## 6. Dashboard
The Power BI dashboard is designed to communicate the analysis through:
- KPI cards for restaurant count, average rating, average/median price, and offers
- Price-category distribution
- Rating-category distribution
- Location-wise restaurant count
- Cuisine analysis
- Vegetarian/non-vegetarian split
- Offer analysis
- Interactive filters for location, area, price category, rating category, cuisine, and pure-veg status

**Dashboard screenshot:** add your final Power BI screenshot to `dashboard/dashboard.png`.

## 7. Key Business Insights
1. The dataset contains **139,321 restaurant listings across 581 locations**, enabling broad geographic comparison.
2. **Budget (64,271) and Moderate (63,400)** restaurants make up the majority of listings.
3. The overall mean restaurant rating among non-missing ratings is **4.04**.
4. The median listed average price is **₹250**, while the mean is **₹270**.
5. **North Indian, Chinese, Indian, Bakery, South Indian and Biryani** are among the frequently represented cuisine categories.
6. The dataset contains **80,826 non-vegetarian** and **58,495 vegetarian** listings.
7. Promotional activity is widespread, with **443,635 total offer records/counts** across the listings.
8. Price outliers should be reviewed as potential premium offerings or data-quality exceptions.
9. Because `number_of_ratings` is unavailable in the supplied file, popularity/customer-engagement conclusions should not be made from that field.

> These are descriptive findings from the supplied dataset; they do not establish causation.

## 8. Repository Structure
```text
SWYNEX-Swiggy-Data-Analytics/
├── README.md
├── FINAL_PROJECT_REPORT.pdf
├── data/
│   └── swiggy_cleaned.csv.gz
├── notebooks/
│   └── Swiggy_EDA_SWYNEX_Task2.ipynb
├── dashboard/
│   ├── dashboard.png
│   └── README.md
└── docs/
    ├── data_dictionary.md
    └── project_summary.md
```

## 9. How to Use
1. Download `data/swiggy_cleaned.csv.gz` and extract it.
2. Open the notebook in Jupyter Notebook or Google Colab.
3. Update the file path if required.
4. Open the Power BI dashboard and refresh the data source.
5. Use the dashboard filters to explore locations, prices, ratings, cuisines, and offers.

## 10. Final Submission
**GitHub URL:** `PASTE-YOUR-GITHUB-REPOSITORY-URL-HERE`

**Author:** Ambika Esapuram  
**Project:** SWYNEX Data Analyst Internship — Swiggy Restaurant Analytics  
