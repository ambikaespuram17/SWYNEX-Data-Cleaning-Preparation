# Dashboard

Place the final Power BI dashboard screenshot here as `dashboard.png`.

Recommended dashboard elements:
- Restaurant count
- Average rating
- Median/average price
- Total offers
- Price category chart
- Rating category chart
- Location-wise restaurant count
- Cuisine analysis
- Vegetarian split
- Interactive slicers
