# Project Summary

This final project demonstrates an end-to-end data analytics workflow:
data preparation → exploratory analysis → visualization → dashboard → business insights.

The analysis is intended for descriptive restaurant-market exploration and dashboard reporting.
