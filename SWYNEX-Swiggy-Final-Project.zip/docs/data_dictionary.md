# Data Dictionary

| Column | Description |
|---|---|
| restaurant_name | Name of the restaurant |
| cuisine | Cuisine/category information |
| rating | Restaurant rating |
| number_of_ratings | Number of customer ratings; unavailable in supplied cleaned file |
| average_price | Listed average price |
| number_of_offers | Number of promotional offers |
| offer_name | Offer/promotion text |
| area | Local area/neighborhood |
| pure_veg | Vegetarian indicator |
| location | City/location |
| price_category | Derived price segment |
| rating_category | Derived rating segment |
| popularity_category | Popularity segment; unavailable in supplied cleaned file |
